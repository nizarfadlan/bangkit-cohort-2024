package com.nizarfadlan.aplikasigithubuser.ui.detailsScreen

import android.view.KeyEvent
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.IdlingRegistry
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.idling.CountingIdlingResource
import androidx.test.espresso.matcher.ViewMatchers.*
import com.google.android.material.search.SearchView
import com.nizarfadlan.aplikasigithubuser.ui.MainActivity
import com.nizarfadlan.aplikasigithubuser.R
import org.hamcrest.Matcher
import org.hamcrest.Matchers.allOf
import org.junit.Before
import org.junit.Test

class DetailFragmentTest {
    private val splashDelay = 8000L
    private val countingIdlingResource = CountingIdlingResource("SplashDelay")
    private val username = "nizarfadlan"

    @Before
    fun setup() {
        IdlingRegistry.getInstance().register(countingIdlingResource)

        ActivityScenario.launch(MainActivity::class.java)
    }

    private fun waitingSplashAndSearch() {
        countingIdlingResource.increment()
        Thread.sleep(splashDelay)
        countingIdlingResource.decrement()

        onView(withId(R.id.rvUsers)).check(matches(isDisplayed()))
        onView(withId(R.id.searchBar)).perform(click())

        onView(withId(R.id.searchView))
            .check(matches(isDisplayed()))
            .perform(click())
            .perform(
                typeSearchViewText(username),
                pressKey(KeyEvent.KEYCODE_ENTER)
            )

        Thread.sleep(1000)

        onView(withId(R.id.rvUsers))
            .check(matches(isDisplayed()))
            .perform(
                RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click())
            )
    }

    @Test
    fun favoriteUser() {
        waitingSplashAndSearch()

        Thread.sleep(500)

        onView(withId(R.id.tvUsername))
            .check(matches(isDisplayed()))
            .check(matches(withText(username)))

        onView(withId(R.id.fabFavorite))
            .check(matches(isDisplayed()))

        setFavoriteUser()
    }

    private fun setFavoriteUser() {
        // Test add to favorite
        onView(withId(R.id.fabFavorite)).perform(click())

        onView(withId(R.id.fabFavorite))
            .check(matches(withContentDescription(R.string.unfavorite)))

        // Test remove from favorite
        onView(withId(R.id.fabFavorite)).perform(click())

        onView(withId(R.id.fabFavorite))
            .check(matches(withContentDescription(R.string.favorite)))
    }
}

fun typeSearchViewText(text: String): ViewAction {
    return object : ViewAction {
        override fun getConstraints(): Matcher<View> {
            return allOf(isDisplayed(), isAssignableFrom(SearchView::class.java))
        }

        override fun getDescription(): String {
            return "Change view text"
        }

        override fun perform(uiController: UiController, view: View) {
            (view as SearchView).setText(text)
        }
    }
}