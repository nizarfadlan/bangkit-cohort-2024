package com.nizarfadlan.aplikasigithubuser.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.nizarfadlan.aplikasigithubuser.data.GithubRepository
import com.nizarfadlan.aplikasigithubuser.utils.ThemeMode

class MainViewModel(private val githubRepository: GithubRepository) : ViewModel() {
    fun getThemeSettings(): LiveData<ThemeMode> = githubRepository.getThemeSettings().asLiveData()
}