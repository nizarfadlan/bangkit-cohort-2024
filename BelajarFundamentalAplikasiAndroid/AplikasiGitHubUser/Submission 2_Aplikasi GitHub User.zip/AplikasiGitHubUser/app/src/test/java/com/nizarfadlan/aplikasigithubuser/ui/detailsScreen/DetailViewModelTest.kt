package com.nizarfadlan.aplikasigithubuser.ui.detailsScreen

import android.arch.core.executor.testing.InstantTaskExecutorRule
import com.nizarfadlan.aplikasigithubuser.data.GithubRepository
import kotlinx.coroutines.*
import org.junit.*
import org.mockito.Mock
import com.nizarfadlan.aplikasigithubuser.data.Result
import com.nizarfadlan.aplikasigithubuser.helpers.MainCoroutineRule
import com.nizarfadlan.aplikasigithubuser.helpers.getOrAwaitValue
import kotlinx.coroutines.test.runTest
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {
    @get:Rule
    val instantTaskExecutorRule: InstantTaskExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    var mainCoroutineRule = MainCoroutineRule()

    @Mock
    private lateinit var repository: GithubRepository
    private lateinit var viewModel: DetailViewModel

    // My username github
    private val username = "nizarfadlan"

    @Before
    fun setUp() {
        repository = mock(GithubRepository::class.java)
        viewModel = DetailViewModel(repository)
    }

    @Test
    fun testUpdateFavoriteUser() = runTest {
        viewModel.getDetailUser(username)

        viewModel.updateFavoriteUser(true, username)

        when(val result = viewModel.detailUser.getOrAwaitValue()) {
            is Result.Success -> {
                println(result)
            }

            is Result.Error -> {
                assert(false)
            }

            else -> {
                assert(false)
            }
        }
    }
}